---
name: task-router
description: Use when an orchestrated coding task needs docs-first research, installed skill or custom-agent selection, local catalog lookup, or safe asset promotion before implementation.
---

# Task Router

Task Router is the orchestrator's routing substep for documentation, skills, and custom agents. It is not a competing top-level workflow and does not replace `orchestrator-stage` or Superpowers.

## Workflow

1. **Confirm orchestration context**
   - Use this after orchestrator-first triage classifies the task as medium/complex, docs-sensitive, unfamiliar, or likely to benefit from a skill or custom agent.
   - If the task is trivial, local, and not version-sensitive, skip routing and let the orchestrator execute locally.

2. **Docs first**
   - If behavior may vary by version, fetch authoritative/current docs before implementation.
   - Use Context7 first for framework/library behavior and first-party docs for APIs, CLIs, infra, or platform behavior.

3. **Check installed assets**
   - Look for matching skills in:
     - `$HOME/.agents/skills/`
     - `$CODEX_HOME/skills/`
     - `$HOME/.agents/skills/superpowers/`
   - Look for matching custom agents in `$CODEX_HOME/agents/`.

4. **Consult the local catalog when needed**
   - If no obvious installed asset fits, consult:
     - `$CODEX_HOME/catalog/index.md`
     - `$CODEX_HOME/catalog/assets.json`
   - If the catalog is stale or source sync errors are present, refresh it first:
     - `python3 "${CODEX_HOME:-$HOME/.codex}/bin/sync_catalog.py"`
     - `python3 "${CODEX_HOME:-$HOME/.codex}/bin/refresh_promoted_assets.py"`
   - Treat external skill packs as reference candidates, not as replacements for the active repo workflow.
   - Use `skill_scout` if ranking the options will help.
   - If a trusted staged asset is the best fit, vet and promote it automatically with:
     - `python3 "${CODEX_HOME:-$HOME/.codex}/bin/vet_asset.py" --source <id> --type <skill|agent> --name "<name>"`
     - `python3 "${CODEX_HOME:-$HOME/.codex}/bin/promote_asset.py" --source <id> --type <skill|agent> --name "<name>"`
   - For delegated work, the orchestrator passes selected docs, skills, agents, and catalog candidates into the subagent prompt or manual fallback prompt.
   - Every delegated prompt must include a `Documentation` block: use MCP Context7 for current docs/examples when dependencies matter, or require `No dependency documentation lookup needed.`
   - Every delegated prompt must include an `Asset Routing` block with `Selected skills`, `Selected agents/personas`, and `Catalog candidates`. If nothing fits, write `none` plus a short reason; do not omit the block.
   - Children should not repeat catalog discovery unless the prompt marks it as specialist-blocked.

5. **Routing output contract**
   - Before launching a subagent or drafting a manual fallback prompt, decide the routing result explicitly:
     - `Documentation`: exact docs source or `No dependency documentation lookup needed.`
     - `Selected skills`: exact skill names/paths, or `none - <reason>`
     - `Selected agents/personas`: exact agent names/paths, or `none - <reason>`
     - `Catalog candidates`: promoted/lookup-only candidate names, or `none - <reason>`
   - Include only assets that lower risk or improve execution; do not add decorative or generic assets.
   - If a suitable installed skill or agent exists, prefer naming it over asking the child to rediscover assets.

6. **Promotion rule**
   - Prefer already-installed assets.
   - Official OpenAI skills may be auto-installed on demand.
   - Community assets may be auto-promoted only when the local policy marks the source as `vetted-community` and static vetting passes.
   - Never auto-promote `catalog-only` community sources, including Codex-native community agents; use them for lookup or ask before changing trust mode.
   - If vetting fails, fall back to direct execution instead of forcing installation.

7. **Hand off to the normal workflow**
   - New behavior or non-trivial change -> `brainstorming`
   - Multi-step task -> `writing-plans`
   - Bug or failure -> `systematic-debugging`
   - Code changes -> `test-driven-development` when appropriate
   - Before claiming done -> `verification-before-completion`

8. **Beads discipline**
   - If work will change files, last more than about 15 minutes, or may need handoff, create or select a Beads task first.
