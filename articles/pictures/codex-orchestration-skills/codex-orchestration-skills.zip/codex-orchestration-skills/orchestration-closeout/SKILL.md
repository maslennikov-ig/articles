---
name: orchestration-closeout
description: Use when a stage or task is ready to finish and needs final verification, delivery handling, and strict local workspace cleanup.
---

# Orchestration Closeout

## Overview

Close work in two phases:
- `stage close`: verify the stage truth and close the engineering scope
- `delivery/workspace closeout`: handle push or PR state, then remove safe local leftovers

Do not treat `stage ready` as the end of work. A finished stage must also leave delivery, local workspace state, and technical-debt state in good order. Child stream cleanup should happen at acceptance time; final closeout is the last safety pass, not the first cleanup checkpoint.

## When To Use

Use this skill when:
- a stage is ready to close
- delegated artifacts were reviewed and accepted
- code or docs delivery is ready to push, PR, or sync
- local worktrees or feature branches created for the stage should be cleaned up

Do not use it for mid-stage progress updates or when delivery is intentionally deferred.

## Two-Phase Closeout

### 1. Stage Close

- read `AGENTS.md`, `.codex/orchestrator.toml`, `.codex/handoff.md`, `.codex/project-index.md`, and the stage artifacts
- confirm every accepted delegated artifact records `delivery_method`, `accepted_by_orchestrator`, `cleanup_status`, and `cleanup_notes`
- require accepted streams to have `cleanup_status: cleaned` or `cleanup_status: blocked` with explicit notes; do not close over `cleanup_status: pending`
- run `scripts/orchestration/run_stage_closeout.py --stage <stage_id>` when present
- if the repo has no dedicated closeout script, run the relevant verification groups, then the process verification entrypoint, then the stage closure check
- decide whether E2E/smoke is applicable; run repo-defined E2E/smoke commands for user-flow or integration risk, or record blocked/not available/not applicable
- check changed lines for new `TODO`, `FIXME`, `HACK`, or `XXX` markers when the repo closeout script supports it
- update `.codex/project-index.md`, or record `project-index: reviewed-no-change` in the stage summary, when the stage changes entrypoints, routes, directories, integrations, verification commands, or major ownership boundaries
- fix in-scope failures before proceeding unless there is a real, explicit defer reason
- do not silently convert avoidable in-scope debt into a vague later cleanup item

### 2. Delivery And Workspace Closeout

- handle delivery according to repo contract:
  - create or update PRs when required
  - push feature branches when allowed
  - ordinary direct push is allowed only when the repo contract says `delivery.mode = "direct"`, `delivery.pr_required = false`, `delivery.primary_branch = "main"`, and `delivery.push_after_closeout = "allowed"`
  - before ordinary direct push, require fresh verification, committed changes, a clean worktree, and no divergence from `origin/main`; if `origin/main` is ahead or histories diverged, stop and ask
  - ordinary direct push command is exactly `git push origin main`
  - merge only when the repo contract and user authorization clearly allow it
  - use repo-specific delivery commands when they are the canonical path
- after delivery, run `scripts/orchestration/cleanup_stage_workspace.py --stage <stage_id>` when present
- remove only safe local worktrees created for the stage
- delete only safe local feature branches after remote delivery or confirmed merge
- do not force-delete accepted cherry-picked/manual-integrated branches unless the user explicitly authorizes it outside normal closeout
- leave protected branches, current branches, and undeployed local-only branches alone

## Hard Boundaries

- never skip required verification just because an artifact says the work is done
- never treat a completion event or child return signal as acceptance by itself
- never merge merely because tests are green if the repo contract still expects PR review or human authorization
- never treat `push_after_closeout = "allowed"` as permission for force-push, remote branch deletion, PR creation, remote merge, deploy, live tests, production mutations, or runtime integrations
- never force-delete dirty worktrees or irreplaceable local branches as part of normal closeout
- never leave silent technical debt behind; if something must be deferred, record the reason, scope, and follow-up task explicitly
- never close with new debt markers unless they are intentionally deferred, tracked in Beads, and visible under `Explicit defers`
- strict clean state means: no avoidable stage-created worktrees or safe-to-delete local stage branches remain after closeout
- strict clean state also means every non-deleted accepted child leftover is explicitly reported with the safety reason

## Repo Contract

Prefer these repo-local entrypoints when they exist:
- `scripts/orchestration/run_stage_closeout.py --stage <stage_id>`
- `scripts/orchestration/cleanup_stage_workspace.py --stage <stage_id>`

Read these fields from `.codex/orchestrator.toml`:
- `verification.*`
- `verification_policy.*`
- `delivery.*`
- `enforcement.*`
- `closeout.*`
- `session_completion.*`
- `debt_scan.*`
- `stage_limits.*`

## Final State

Do not claim closeout is complete until all of this is true:
- verification passed for the touched scope
- E2E/smoke applicability was decided, with required repo-defined checks run or explicitly recorded
- the stage is referenced correctly in handoff and stage files
- the project index is updated or explicitly reviewed as unchanged for structural stages
- handoff includes `Next stage id`, `Recommended action`, `Starter prompt for next orchestrator`, and `Explicit defers`
- no silent technical debt remains; any explicit defer is justified, bounded, tracked in Beads, and visible in handoff
- no new untracked debt markers remain in changed lines
- delivery state matches repo policy
- Beads reflects the new truth
- avoidable local stage worktrees and branches were cleaned or explicitly reported
- per-child acceptance cleanup is complete or explicitly blocked for every accepted delegated artifact
