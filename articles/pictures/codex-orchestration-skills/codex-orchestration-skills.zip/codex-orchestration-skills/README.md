# Codex Orchestration Skills

Четыре локальных skill для Codex CLI: `orchestration-setup`, `orchestrator-stage`, `task-router`, `orchestration-closeout`.
Текущий baseline: `balanced-v2.12` (срез на 2026-05-18).

Подробный разбор системы и зачем она такая — в статье на Хабре:
**[Собрал оркестратор для Codex на базе Beads и Superpowers — 4 skill, параллельные subagents, наблюдаемость](https://habr.com/ru/articles/[добавить-после-публикации]/)**

Предыдущий пост про связку Claude Code + Superpowers + Beads + Template Bridge:
**[3000+ часов в Claude Code: как я сконцентрировал весь опыт в трёх плагинах](https://habr.com/ru/articles/1017110/)**

## Что внутри

| Skill | Зачем |
|---|---|
| `orchestration-setup` | Инициализация и audit repo-local baseline (AGENTS.md, `.codex/orchestrator.toml`, handoff, шаблоны, support scripts). |
| `orchestrator-stage` | Ведение medium/complex этапа: routing, Parallel Decomposition Matrix, spawning subagents, review. |
| `task-router` | Routing substep — выбор актуальных docs, skills, custom agents, локального каталога. |
| `orchestration-closeout` | Закрытие этапа: verification, delivery по политике repo, безопасный cleanup worktrees/branches. |

Плюс шаблоны (`baseline.toml`, `subagent-task-contract.md`, `subagent-spawn-template.md`, `stage-artifact-template.md`, `manual-agent-prompt-template.md`, `project-index-template.md`) и support-скрипты (`audit_repo.py`, `sync_support_files.py`, плюс `templates/scripts/*` — process verification, completion inbox, stage closeout, cleanup workspace).

## Как поставить

```bash
unzip codex-orchestration-skills.zip -d ~/.agents/skills/
```

После распаковки структура такая:

```
~/.agents/skills/
├── orchestration-setup/
├── orchestrator-stage/
├── task-router/
└── orchestration-closeout/
```

Скиллы привязаны к локальной системе вызова через `$skill-name` в Codex (см. `developers.openai.com/codex/concepts/customization`). Если у вас другой механизм подключения — посмотрите путь, по которому ваш Codex CLI читает skills, и положите туда.

## Что нужно настроить под себя

1. **`AGENTS.md` в каждом проекте.** В нём — repo-specific contract: где код, какие verification commands, что Beads = task truth. `orchestration-setup` подскажет шаблон, но содержимое — ваше.
2. **`.codex/orchestrator.toml`.** Скилл создаст его по `baseline.toml`. Проверьте поля `verification`, `delivery`, paths под ваш репозиторий.
3. **Beads.** Скиллы предполагают, что у вас стоит Beads. Без него часть workflow не работает — она опирается на `bd ready`, `bd create`, dependency graph.
4. **Superpowers.** Скиллы используют процессные skills из Superpowers (`brainstorming`, `writing-plans`, `test-driven-development`, `verification-before-completion`, `using-git-worktrees`). Поставьте их отдельно — это другой пакет.

## Контакты

- Telegram-канал: https://t.me/maslennikovigor — туда выкладываю обновления baseline.
- Прямой контакт: https://t.me/maslennikovig.
- GitHub: https://github.com/maslennikov-ig/claude-code-orchestrator-kit — это про Claude Code, не Codex. Codex-версия — то, что в этом архиве.

## Лицензия и дисклеймер

Бесплатно, MIT. Используйте, форкайте, переделывайте.
Baseline `balanced-v2.12` — это срез на момент публикации статьи. Codex быстро меняется (subagents, sandbox, customization). Если через полгода что-то перестало работать — это нормально, проверьте changelog Codex и обновите шаблоны.
