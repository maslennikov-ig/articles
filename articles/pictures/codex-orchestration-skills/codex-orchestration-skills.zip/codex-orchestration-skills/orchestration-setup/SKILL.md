---
name: orchestration-setup
description: Use when a repository or project folder needs the shared AGENTS-first orchestration baseline initialized, audited for drift, or reconciled to the current baseline.
---

# Orchestration Setup

## Overview

Initialize, audit, or reconcile the shared orchestration baseline `balanced-v2.12`.
The baseline is AGENTS-first, Beads-backed, and auto-subagent-capable:

- `AGENTS.md` is the short human contract.
- `.codex/orchestrator.toml` is the thin machine contract.
- `.codex/handoff.md` is current state only.
- `.codex/project-index.md` is the stable navigation map.
- `.codex/stages/...` stores stage history and delegated artifacts.
- `.codex/subagent-task-contract.md` defines worker-facing delegated-stream rules.
- `.codex/subagent-spawn-template.md` defines the concrete auto-subagent prompt shape.
- Auto-subagent mode means separate spawned Codex agent threads/runs with role/name visibility; inline summaries are not a valid substitute.
- Medium/complex work requires a Parallel Decomposition Matrix before implementation.
- Subagent model/reasoning selection is policy-driven: inherit by default, raise reasoning for risk/complexity, and override model only with current user authorization or a clear task-specific reason.
- Manual-launch prompts are legacy/fallback only.
- No global startup/session hooks are part of the baseline.
- Superpowers, Beads, Asset Routing, Documentation, verification, and no-silent-debt rules remain mandatory.

Keep the baseline minimal. Do not add a second task ledger on top of Beads.

## When To Use

Use this skill when:

- a repo has no orchestration contract yet
- a new folder or fresh repo needs the shared orchestration system
- an existing repo has orchestration files that may have drifted
- a repo still uses heavy handoff/report sprawl or manual-first delegation
- the shared baseline itself gained managed files, contract keys, or support scripts

Do not use it for one-off task execution inside a repo that already has a stable baseline.

## Operating Modes

Pick one mode before editing:

- `initialize`: create the baseline in a repo missing the live surface
- `audit`: classify existing files as `aligned`, `aligned_with_exceptions`, or `drifted`
- `reconcile`: safely update a partially initialized or drifted repo to the current baseline

Before editing, determine:

- repo topology: single-repo or multi-repo
- delivery mode: direct, PR-only, or mixed
- delegation launcher: `codex_subagents`, `manual_user_launch`, or `none`
- canonical verification commands
- current stage id if migrating an active stage

Default new repos to `delegation.launcher = "codex_subagents"`. Preserve explicit legacy manual-launch repos as `manual_user_launch`.
For `codex_subagents`, record `subagent_visibility = "separate_spawned_threads"`, `inline_subagents_allowed = false`, and `requires_explicit_user_spawn_request = true`.
Also record `parallel_decomposition_matrix = "required_for_medium_complex"`, `parallel_execution_default = "spawn_all_independent_streams"`, and `sequential_requires_reason = true`.
Add `[subagent_model_policy]` with `default_model = "inherit_orchestrator"`, `default_reasoning_effort = "inherit_orchestrator"`, `reasoning_policy = "complexity_based"`, `model_override_requires_current_user_authorization = true`, and `record_model_reasoning_rationale = true`.
Default write-heavy delegated streams to dedicated branch/worktree isolation unless the repo records an explicit shared-workspace exception.

## Managed Surface

Core managed files:

- `AGENTS.md`
- `.codex/orchestrator.toml`
- `.codex/handoff.md`
- `.codex/project-index.md`
- `.codex/stage-artifact-template.md`
- `.codex/subagent-task-contract.md`
- `.codex/subagent-spawn-template.md`
- `scripts/orchestration/run_process_verification.sh`
- `scripts/orchestration/validate_artifact.py`
- `scripts/orchestration/check_stage_ready.py`
- `scripts/orchestration/run_stage_closeout.py`
- `scripts/orchestration/cleanup_stage_workspace.py`
- `scripts/orchestration/report_child_completion.py`
- `scripts/orchestration/review_completion_inbox.py`

Legacy/fallback manual-launch repos also require:

- `.codex/manual-agent-prompt-template.md`

Historical archives are not managed unless a repo explicitly promotes them back into live use.

Do not install, require, or refresh global Codex hooks. If old startup/session hook files are found during setup work, treat them as legacy external clutter and remove them only when the user explicitly asks.

## Repo Contract

`AGENTS.md` should stay compact and stable. Include only:

- project shape and main entrypoints
- canonical verification entrypoint
- autonomy and delivery boundaries
- current operational-state location
- orchestrator-first triage reminder: simple work stays local; medium/complex work uses `orchestrator-stage` and `task-router`
- delegated work reminder: justified delegation uses separate spawned Codex subagents by default; inline summaries are not a substitute; manual prompt packs are fallback/legacy only
- Beads reminder: create or select a Beads task before file-changing, delegated, >15 minute, or handoff-prone work
- Superpowers reminder: routing does not replace the required process skill after routing
- prompt/agent reminder: delegated streams include Documentation and Asset Routing blocks
- parallel planning reminder: medium/complex work starts with a Parallel Decomposition Matrix and spawns all independent streams in parallel when subagents are authorized
- model/reasoning reminder: subagents inherit model/reasoning by default; high-risk streams can use higher reasoning; model override needs current user authorization or a clear task-specific reason
- isolation reminder: write-heavy worker streams use dedicated branch/worktree unless the repo explicitly allows shared workspace
- no-silent-technical-debt policy
- child acceptance mini-closeout reminder

`.codex/orchestrator.toml` should stay thin and machine-readable:

- `role = "orchestrator-stage"`
- `[baseline] profile = "balanced-v2.12"` and `source_skill = "orchestration-setup"`
- `[workspace]` topology and repo paths
- `[delegation] launcher = "codex_subagents"` for the default baseline
- `[delegation] subagent_visibility = "separate_spawned_threads"`, `inline_subagents_allowed = false`, and `requires_explicit_user_spawn_request = true`
- `[delegation] parallel_decomposition_matrix = "required_for_medium_complex"`, `parallel_execution_default = "spawn_all_independent_streams"`, and `sequential_requires_reason = true`
- `[subagent_model_policy]` default inheritance, complexity-based reasoning, current-user authorization for model override, and rationale recording
- write-heavy delegation isolation defaults; repo-specific shared-workspace exceptions must be explicit
- verification commands, optional E2E/smoke commands, and risk triggers
- artifact, handoff, project index, completion inbox, and enforcement paths
- delivery toggles, protected branches, and repo-specific exceptions
- optional limits: `stage_limits.*`, `prompt_cache.*`, `debt_scan.*`
- `manual_prompt_template` only for `manual_user_launch` repos

`.codex/handoff.md` must be current-state only and include:

- `Next stage id`
- `Recommended action`
- `Starter prompt for next orchestrator`
- `Explicit defers`

`.codex/project-index.md` must be a stable navigation map:

- 80-150 lines by default
- runtime shape and primary entrypoints
- core subsystems and ownership boundaries
- integrations and source-of-truth precedence
- canonical verification commands
- durable repo-local conventions

Do not put stage history, deployment logs, current blockers, or handoff sections in the project index.

## Audit Rules

Classify the repo as:

- `uninitialized`: missing the managed surface entirely
- `partially_initialized`: some baseline files exist, but the live contract is incomplete
- `aligned`: current profile marker, managed surface, and process verification pass
- `aligned_with_exceptions`: current baseline plus explicit repo-local exceptions
- `drifted`: stale profile, missing guardrails, manual-first drift, handoff/report sprawl, duplicate task ledger, hook dependency, or failed verification

Safe reconcile fixes:

- add missing baseline files and `[baseline]` markers
- refresh template-managed support files from this skill
- add `.codex/subagent-task-contract.md`
- add `.codex/subagent-spawn-template.md`
- preserve or add `delegation.launcher`
- preserve or add parallel decomposition defaults
- preserve or add subagent model/reasoning policy defaults
- preserve or add Beads/Superpowers/Asset Routing reminders without expanding `AGENTS.md` into a long policy file
- preserve or add write-heavy branch/worktree isolation defaults
- preserve explicit `manual_user_launch` repos and add `.codex/manual-agent-prompt-template.md` only there
- compact `.codex/handoff.md` back to current-state only
- create `.codex/project-index.md` when missing; preserve valid existing content
- move active stage history into `.codex/stages/<stage_id>/summary.md`
- add or refresh completion inbox and closeout entrypoints
- add or refresh `## Explicit defers`; use `- none` when no defer exists
- remove repo-local references that require global startup/session hooks

Do not guess repo-specific delivery rules, deployment flows, topology, or architecture constraints. If those are unclear, stop and ask for the exact decision.

## Support Files

Read `templates/baseline.toml` for the current managed surface and profile marker.

Use bundled helpers first:

- `python3 support/audit_repo.py <repo-path>`
- `python3 support/sync_support_files.py <repo-path>`

Copy guardrail scripts and templates from `templates/`, then adapt only repo-specific verification commands, topology, delivery rules, launcher mode, and justified exceptions.

When reconciling:

- refresh copied support files from templates when safe
- preserve tracked stage history
- preserve canonical verification commands and delivery constraints
- preserve explicit `delivery.push_after_closeout = "allowed"` only for trusted direct-delivery repos
- keep Beads as the only task truth and never create `tasks.json`
- keep manual fallback subject to the same Beads, Superpowers, Asset Routing, Documentation, verification, and isolation rules
- keep `AGENTS.md` short; do not expand local reminders into a long policy block
- do not rewrite historical archives unless explicitly asked

## Verification

After initialize or reconcile:

- run `scripts/orchestration/run_process_verification.sh`
- if an active stage was migrated, run `python3 scripts/orchestration/check_stage_ready.py <stage_id>`
- confirm the contract mentions Beads as the only task truth and does not introduce `tasks.json`
- confirm `.codex/handoff.md` includes a non-empty `## Explicit defers`
- confirm `.codex/project-index.md` has required navigation sections and stays within limit
- confirm `.codex/subagent-task-contract.md` exists
- confirm `.codex/subagent-spawn-template.md` exists
- confirm the repo contract requires a Parallel Decomposition Matrix and a reason for sequential execution
- confirm `[subagent_model_policy]` inherits defaults, allows complexity-based reasoning, and requires current user authorization for model override
- confirm manual template is present only for `manual_user_launch`
- report `aligned`, `aligned_with_exceptions`, or `drifted`
