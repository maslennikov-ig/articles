# Project Index

Stable navigation map for this repository. Keep this file factual, compact, and
free of stage history or current task status.

## Runtime Shape

- Describe the repository topology and primary runtime in 3-5 bullets.
- Name the main application entrypoint and the canonical live/runtime target if
  the repo has one.

## Primary Entrypoints

- `AGENTS.md` - repo contract and operator rules.
- `.codex/orchestrator.toml` - machine-readable orchestration contract.
- `.codex/handoff.md` - current operational state only.
- Add the main app, worker, CLI, frontend, or deployment entrypoints.

## Core Subsystems

- List the stable subsystem directories and what each owns.
- Prefer durable boundaries over exhaustive file lists.

## Integrations And Sources Of Truth

- List external systems, APIs, databases, queues, and business truth sources.
- Note which source wins when data conflicts.

## Verification

- List canonical process and code-change verification commands.
- Keep this aligned with `.codex/orchestrator.toml`.

## Conventions And Boundaries

- Record stable repo-local conventions that affect navigation or safe edits.
- Do not store stage history, deployment logs, temporary blockers, or task state.
