#!/usr/bin/env python3
"""Sync template-managed orchestration support files into a repository."""

from __future__ import annotations

import argparse
import pathlib
import shutil
import sys
import tomllib


def load_manifest(skill_dir: pathlib.Path) -> dict:
    manifest_path = skill_dir / "templates" / "baseline.toml"
    return tomllib.loads(manifest_path.read_text())


def file_mode(path: pathlib.Path) -> int:
    if path.suffix in {".py", ".sh"}:
        return 0o755
    return 0o644


def template_path(skill_dir: pathlib.Path, repo_relative: str) -> pathlib.Path:
    if repo_relative == ".codex/project-index.md":
        return skill_dir / "templates" / "project-index-template.md"
    if repo_relative == ".codex/stage-artifact-template.md":
        return skill_dir / "templates" / "stage-artifact-template.md"
    if repo_relative == ".codex/subagent-task-contract.md":
        return skill_dir / "templates" / "subagent-task-contract.md"
    if repo_relative == ".codex/subagent-spawn-template.md":
        return skill_dir / "templates" / "subagent-spawn-template.md"
    if pathlib.Path(repo_relative).name == "manual-agent-prompt-template.md":
        return skill_dir / "templates" / "manual-agent-prompt-template.md"
    if repo_relative.startswith("scripts/orchestration/"):
        return skill_dir / "templates" / "scripts" / pathlib.Path(repo_relative).name
    return skill_dir / "templates" / repo_relative


def load_contract(repo_root: pathlib.Path) -> dict | None:
    orchestrator_path = repo_root / ".codex" / "orchestrator.toml"
    if not orchestrator_path.exists():
        return None
    return tomllib.loads(orchestrator_path.read_text())


def delegation_launcher(contract: dict | None) -> str:
    if not isinstance(contract, dict):
        return "codex_subagents"
    delegation = contract.get("delegation")
    if isinstance(delegation, dict) and isinstance(delegation.get("launcher"), str):
        return delegation["launcher"]
    workspace = contract.get("workspace")
    if isinstance(workspace, dict) and workspace.get("launch_mode") == "manual_user_launch":
        return "manual_user_launch"
    return "codex_subagents"


def first_heading(repo_root: pathlib.Path) -> str:
    readme = repo_root / "README.md"
    if readme.exists():
        for line in readme.read_text(errors="ignore").splitlines():
            if line.startswith("# "):
                return line.removeprefix("# ").strip()
    return repo_root.name


def existing_paths(repo_root: pathlib.Path, candidates: list[str]) -> list[str]:
    return [path for path in candidates if (repo_root / path).exists()]


def verification_commands(contract: dict | None) -> list[str]:
    if not isinstance(contract, dict):
        return []
    verification = contract.get("verification")
    if not isinstance(verification, dict):
        return []
    commands: list[str] = []
    for key in ("process_only_commands", "code_change_commands", "stage_close_commands"):
        raw = verification.get(key)
        if isinstance(raw, list):
            commands.extend(str(item) for item in raw[:4])
    return commands[:8]


def build_project_index(repo_root: pathlib.Path, contract: dict | None) -> str:
    title = first_heading(repo_root)
    entrypoints = existing_paths(
        repo_root,
        [
            "AGENTS.md",
            "README.md",
            ".codex/orchestrator.toml",
            ".codex/handoff.md",
            "src/main.py",
            "src/worker.py",
            "frontend/admin",
            "scripts/orchestration/run_process_verification.sh",
        ],
    )
    subsystems = existing_paths(
        repo_root,
        [
            "src/api",
            "src/core",
            "src/models",
            "src/schemas",
            "src/llm",
            "src/rag",
            "src/integrations",
            "src/services",
            "src/quality",
            "migrations",
            "tests",
            "docs",
        ],
    )
    verification = verification_commands(contract)

    lines = [
        f"# Project Index - {title}",
        "",
        "Stable navigation map for this repository. Keep history and current task state in `.codex/handoff.md` and `.codex/stages/`, not here.",
        "",
        "## Runtime Shape",
        "",
        "- Single repository unless `.codex/orchestrator.toml` says otherwise.",
        "- Use `AGENTS.md` as the primary contract before this index.",
        "- Keep this section updated when runtime entrypoints or deployment shape change.",
        "",
        "## Primary Entrypoints",
        "",
    ]
    lines.extend(f"- `{path}`" for path in entrypoints)
    lines.extend(
        [
            "",
            "## Core Subsystems",
            "",
        ]
    )
    lines.extend(f"- `{path}`" for path in subsystems)
    lines.extend(
        [
            "",
            "## Integrations And Sources Of Truth",
            "",
            "- Check `README.md`, `AGENTS.md`, and repo docs for external systems and data ownership.",
            "- Record source-of-truth precedence here when integrations or business data flows change.",
            "",
            "## Verification",
            "",
        ]
    )
    if verification:
        lines.extend(f"- `{command}`" for command in verification)
    else:
        lines.append("- Use repo-local commands from `.codex/orchestrator.toml`.")
    lines.extend(
        [
            "",
            "## Conventions And Boundaries",
            "",
            "- Do not store stage history, deployment logs, current blockers, or task status in this file.",
            "- Update this index when entrypoints, routes, directories, integrations, verification commands, or ownership boundaries change.",
            "- Keep the file compact; prefer durable subsystem boundaries over exhaustive file inventories.",
            "",
        ]
    )
    return "\n".join(lines)


def sync_project_index(repo_root: pathlib.Path, manifest: dict, contract: dict | None) -> str | None:
    relative = str(manifest.get("project_index_path", ".codex/project-index.md"))
    if isinstance(contract, dict):
        configured = contract.get("project_index_file")
        if isinstance(configured, str) and configured:
            relative = configured

    dst = repo_root / relative
    if dst.exists():
        return None

    legacy = repo_root / ".Codex" / "project-index.md"
    dst.parent.mkdir(parents=True, exist_ok=True)
    if legacy.exists():
        shutil.copyfile(legacy, dst)
    else:
        dst.write_text(build_project_index(repo_root, contract))
    dst.chmod(0o644)
    return relative


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo_path", nargs="?", default=".")
    args = parser.parse_args(argv[1:])

    skill_dir = pathlib.Path(__file__).resolve().parent.parent
    repo_root = pathlib.Path(args.repo_path).resolve()
    manifest = load_manifest(skill_dir)
    contract = load_contract(repo_root)

    synced: list[str] = []
    for relative in manifest["sync_from_templates"]:
        src = template_path(skill_dir, relative)
        dst = repo_root / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        dst.chmod(file_mode(src))
        synced.append(relative)

    if isinstance(contract, dict):
        if delegation_launcher(contract) == "manual_user_launch":
            default_relative = ".codex/manual-agent-prompt-template.md"
            relative = contract.get("manual_prompt_template", default_relative)
            if not isinstance(relative, str) or not relative:
                relative = default_relative
            dst = repo_root / relative
            if not dst.exists():
                src = template_path(skill_dir, relative)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dst)
                dst.chmod(file_mode(src))
                synced.append(relative)

    project_index = sync_project_index(repo_root, manifest, contract)
    if project_index:
        synced.append(project_index)

    print(f"synced {len(synced)} files into {repo_root}")
    for relative in synced:
        print(relative)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
