#!/usr/bin/env python3
"""Audit a repository against the orchestration-setup baseline."""

from __future__ import annotations

import argparse
import filecmp
import json
import pathlib
import re
import sys
import tomllib


def load_manifest(skill_dir: pathlib.Path) -> dict:
    manifest_path = skill_dir / "templates" / "baseline.toml"
    return tomllib.loads(manifest_path.read_text())


def rel(path: pathlib.Path, root: pathlib.Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def template_path(skill_dir: pathlib.Path, repo_relative: str) -> pathlib.Path:
    if repo_relative == ".codex/project-index.md":
        return skill_dir / "templates" / "project-index-template.md"
    if repo_relative == ".codex/stage-artifact-template.md":
        return skill_dir / "templates" / "stage-artifact-template.md"
    if repo_relative == ".codex/subagent-task-contract.md":
        return skill_dir / "templates" / "subagent-task-contract.md"
    if repo_relative == ".codex/subagent-spawn-template.md":
        return skill_dir / "templates" / "subagent-spawn-template.md"
    if pathlib.Path(repo_relative).name == "manual-agent-prompt-template.md":
        return skill_dir / "templates" / "manual-agent-prompt-template.md"
    if repo_relative.startswith("scripts/orchestration/"):
        return skill_dir / "templates" / "scripts" / pathlib.Path(repo_relative).name
    return skill_dir / "templates" / repo_relative


def delegation_launcher(contract: dict | None) -> str:
    if not isinstance(contract, dict):
        return "codex_subagents"
    delegation = contract.get("delegation")
    if isinstance(delegation, dict) and isinstance(delegation.get("launcher"), str):
        return delegation["launcher"]
    workspace = contract.get("workspace")
    if not isinstance(workspace, dict) or workspace.get("launch_mode") != "manual_user_launch":
        return "codex_subagents"
    return "manual_user_launch"


def manual_launch_required_paths(repo_root: pathlib.Path, manifest: dict, contract: dict | None) -> list[pathlib.Path]:
    if delegation_launcher(contract) != "manual_user_launch":
        return []
    default_relative = ".codex/manual-agent-prompt-template.md"
    configured_relative = contract.get("manual_prompt_template", default_relative)
    if not isinstance(configured_relative, str) or not configured_relative:
        configured_relative = default_relative
    return [repo_root / configured_relative]


def project_index_path(repo_root: pathlib.Path, manifest: dict, contract: dict | None) -> pathlib.Path:
    default_relative = manifest.get("project_index_path", ".codex/project-index.md")
    configured_relative = default_relative
    if isinstance(contract, dict):
        raw_path = contract.get("project_index_file", default_relative)
        if isinstance(raw_path, str) and raw_path:
            configured_relative = raw_path
    return repo_root / str(configured_relative)


def validate_project_index(repo_root: pathlib.Path, manifest: dict, contract: dict | None) -> list[str]:
    issues: list[str] = []
    canonical = project_index_path(repo_root, manifest, contract)
    legacy = repo_root / ".Codex" / "project-index.md"

    if not canonical.exists():
        if legacy.exists():
            issues.append(
                f"project index uses legacy path {rel(legacy, repo_root)}; canonical path is {rel(canonical, repo_root)}"
            )
        return issues

    text = canonical.read_text()
    lines = text.splitlines()
    max_lines = manifest.get("project_index_max_lines", 150)
    if isinstance(contract, dict):
        project_index = contract.get("project_index")
        if isinstance(project_index, dict) and isinstance(project_index.get("max_lines"), int):
            max_lines = project_index["max_lines"]
    if isinstance(max_lines, int) and len(lines) > max_lines:
        issues.append(
            f"{rel(canonical, repo_root)} has {len(lines)} lines, exceeds limit {max_lines}"
        )

    required_sections = manifest.get("project_index_required_sections", [])
    if isinstance(contract, dict):
        project_index = contract.get("project_index")
        if isinstance(project_index, dict) and isinstance(project_index.get("required_sections"), list):
            required_sections = project_index["required_sections"]
    missing_sections = [
        str(section)
        for section in required_sections
        if isinstance(section, str) and section not in text
    ]
    if missing_sections:
        issues.append(
            f"{rel(canonical, repo_root)} is missing required sections: {', '.join(missing_sections)}"
        )

    forbidden_markers = (
        "## Current truth",
        "## Next recommended",
        "## Explicit defers",
        "## Deployment log",
        "## Stage history",
    )
    forbidden_hits = [marker for marker in forbidden_markers if marker.lower() in text.lower()]
    if forbidden_hits:
        issues.append(
            f"{rel(canonical, repo_root)} appears to contain handoff/history material: {', '.join(forbidden_hits)}"
        )

    return issues


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo_path", nargs="?", default=".")
    parser.add_argument("--json", action="store_true", dest="as_json")
    args = parser.parse_args(argv[1:])

    skill_dir = pathlib.Path(__file__).resolve().parent.parent
    repo_root = pathlib.Path(args.repo_path).resolve()
    manifest = load_manifest(skill_dir)

    contract: dict | None = None
    orchestrator_path = repo_root / ".codex" / "orchestrator.toml"
    if orchestrator_path.exists():
        contract = tomllib.loads(orchestrator_path.read_text())

    managed_surface = [repo_root / path for path in manifest["managed_surface"]]
    managed_surface.extend(manual_launch_required_paths(repo_root, manifest, contract))
    existing = [path for path in managed_surface if path.exists()]
    missing = [rel(path, repo_root) for path in managed_surface if not path.exists()]

    status = "aligned"
    issues: list[str] = []
    stale_support: list[str] = []

    if not existing:
        status = "uninitialized"
        issues.append("managed surface is missing entirely")
    elif missing:
        status = "partially_initialized"
        issues.append(f"missing managed files: {', '.join(missing)}")

    if orchestrator_path.exists():
        baseline = contract.get("baseline")
        if not isinstance(baseline, dict):
            status = "drifted"
            issues.append("missing [baseline] section in .codex/orchestrator.toml")
        else:
            expected_profile = manifest["profile"]
            expected_source = manifest["source_skill"]
            if baseline.get("profile") != expected_profile or baseline.get("source_skill") != expected_source:
                status = "drifted"
                issues.append(
                    "baseline marker does not match current skill baseline "
                    f"({baseline.get('profile')!r}, {baseline.get('source_skill')!r})"
                )
        if contract.get("role") != "orchestrator-stage":
            status = "drifted"
            issues.append("orchestrator role must be 'orchestrator-stage'")
        launcher = delegation_launcher(contract)
        if launcher not in {"codex_subagents", "manual_user_launch", "none"}:
            status = "drifted"
            issues.append(
                "delegation.launcher must be one of: codex_subagents, manual_user_launch, none"
            )
        delegation = contract.get("delegation")
        if launcher == "codex_subagents":
            if not isinstance(delegation, dict):
                status = "drifted"
                issues.append("missing [delegation] section for codex_subagents")
            else:
                if delegation.get("subagent_visibility") != "separate_spawned_threads":
                    status = "drifted"
                    issues.append(
                        "delegation.subagent_visibility must be 'separate_spawned_threads'"
                    )
                if delegation.get("inline_subagents_allowed") is not False:
                    status = "drifted"
                    issues.append("delegation.inline_subagents_allowed must be false")
                if delegation.get("requires_explicit_user_spawn_request") is not True:
                    status = "drifted"
                    issues.append(
                        "delegation.requires_explicit_user_spawn_request must be true"
                    )
                if delegation.get("parallel_decomposition_matrix") != "required_for_medium_complex":
                    status = "drifted"
                    issues.append(
                        "delegation.parallel_decomposition_matrix must be 'required_for_medium_complex'"
                    )
                if delegation.get("parallel_execution_default") != "spawn_all_independent_streams":
                    status = "drifted"
                    issues.append(
                        "delegation.parallel_execution_default must be 'spawn_all_independent_streams'"
                    )
                if delegation.get("sequential_requires_reason") is not True:
                    status = "drifted"
                    issues.append("delegation.sequential_requires_reason must be true")
        completion_inbox = contract.get("completion_inbox")
        if not isinstance(completion_inbox, dict):
            status = "drifted"
            issues.append("missing [completion_inbox] section in .codex/orchestrator.toml")
        else:
            for key in (
                "scope",
                "events_file",
                "review_state_file",
                "report_entrypoint",
                "review_entrypoint",
            ):
                if not completion_inbox.get(key):
                    status = "drifted"
                    issues.append(f"completion_inbox.{key} is required")
        model_policy = contract.get("subagent_model_policy")
        if launcher == "codex_subagents":
            if not isinstance(model_policy, dict):
                status = "drifted"
                issues.append("missing [subagent_model_policy] section for codex_subagents")
            else:
                expected_model_policy = {
                    "default_model": "inherit_orchestrator",
                    "default_reasoning_effort": "inherit_orchestrator",
                    "reasoning_policy": "complexity_based",
                    "model_override_requires_current_user_authorization": True,
                    "record_model_reasoning_rationale": True,
                }
                for key, expected in expected_model_policy.items():
                    if model_policy.get(key) != expected:
                        status = "drifted"
                        issues.append(f"subagent_model_policy.{key} must be {expected!r}")
                triggers = model_policy.get("high_reasoning_triggers")
                if not isinstance(triggers, list) or not triggers:
                    status = "drifted"
                    issues.append(
                        "subagent_model_policy.high_reasoning_triggers must be a non-empty list"
                    )
    elif existing:
        status = "partially_initialized"
        issues.append("missing .codex/orchestrator.toml")

    handoff_path = repo_root / ".codex" / "handoff.md"
    if handoff_path.exists():
        handoff_text = handoff_path.read_text()
        required_handoff_tokens = [
            "## Next recommended",
            "Next stage id:",
            "Recommended action:",
            "## Starter prompt for next orchestrator",
            "Use $orchestrator-stage",
            "## Explicit defers",
        ]
        missing_handoff_tokens = [token for token in required_handoff_tokens if token not in handoff_text]
        if missing_handoff_tokens:
            status = "drifted"
            issues.append(
                "handoff is missing required fields: "
                + ", ".join(missing_handoff_tokens)
            )
        explicit_defers_match = re.search(
            r"^## Explicit defers\s*\n(?P<body>.*?)(?=^## |\Z)",
            handoff_text,
            re.MULTILINE | re.DOTALL,
        )
        if not explicit_defers_match:
            status = "drifted"
            issues.append("handoff is missing the Explicit defers section")
        elif not explicit_defers_match.group("body").strip():
            status = "drifted"
            issues.append("handoff has an empty Explicit defers section")

    project_index_issues = validate_project_index(repo_root, manifest, contract)
    if project_index_issues:
        status = "drifted"
        issues.extend(project_index_issues)

    for blocked in (repo_root / "tasks.json", repo_root / ".codex" / "tasks.json"):
        if blocked.exists():
            status = "drifted"
            issues.append(f"duplicate task ledger present: {rel(blocked, repo_root)}")

    for relative in manifest["sync_from_templates"]:
        repo_file = repo_root / relative
        template_file = template_path(skill_dir, relative)
        if repo_file.exists() and not filecmp.cmp(template_file, repo_file, shallow=False):
            stale_support.append(relative)

    if stale_support:
        status = "drifted"
        issues.append(f"template-managed files need sync: {', '.join(stale_support)}")

    result = {
        "repo": str(repo_root),
        "status": status,
        "profile": manifest["profile"],
        "source_skill": manifest["source_skill"],
        "missing": missing,
        "stale_support": stale_support,
        "issues": issues,
    }

    if args.as_json:
        print(json.dumps(result, indent=2, ensure_ascii=True))
    else:
        print(f"repo: {repo_root}")
        print(f"status: {status}")
        print(f"profile: {manifest['profile']}")
        if missing:
            print(f"missing: {', '.join(missing)}")
        if stale_support:
            print(f"stale_support: {', '.join(stale_support)}")
        if issues:
            print("issues:")
            for issue in issues:
                print(f"- {issue}")
        else:
            print("issues: none")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
