---
name: orchestrator-stage
description: "Use when a task is medium or complex and needs engineering orchestration, delegated work review, repo-local stage closeout, or orchestration contract refresh."
---

# Orchestrator Stage

## Overview

For medium or complex work, run lightweight orchestration before execution:
inspect the repo contract, route docs/skills/agents, decide whether delegation helps,
build a Parallel Decomposition Matrix, launch justified separate Codex subagents when permitted,
review returned work, and verify before close.

Simple work stays local. Orchestrator-first does not mean delegate-first.

Shared operating model:

- `AGENTS.md` is primary.
- `.codex/orchestrator.toml` is the thin runtime contract.
- `.codex/handoff.md` is current-state only.
- `.codex/project-index.md` is the stable repo navigation map.
- `.codex/stages/...` stores short stage history and artifacts.
- `.codex/subagent-task-contract.md` carries worker-facing delegated-stream rules.
- `.codex/subagent-spawn-template.md` is the concrete prompt shape for launched subagents.
- `codex_subagents` means separate spawned agent threads/runs visible in the Codex app/CLI, with role/name visibility. Inline chat summaries are not an acceptable substitute.
- A Parallel Decomposition Matrix is required before implementation for every medium/complex stage.
- Subagent model/reasoning selection is explicit and recorded: inherit by default, raise reasoning for complexity/risk, and override model only with current user authorization or a clear task-specific reason.
- Beads is task truth.
- Completion inbox events are return transport, not acceptance truth.
- No silent technical debt.
- Superpowers remain mandatory; routing and delegation never replace the normal process skills.

## Hard Invariants

- Respect higher-priority runtime instructions, sandbox policy, and explicit user permissions.
- Keep `AGENTS.md` primary and compact.
- Keep handoff current-state only; update it when current truth changes.
- Keep project index navigation-only; update it when stable architecture, entrypoints, integrations, verification commands, or ownership boundaries change.
- Do not mix unrelated scope into one delivery stream.
- Use isolated branches/worktrees when the repo contract requires them.
- Use a dedicated branch/worktree for write-heavy worker streams unless the repo contract explicitly allows a shared local workspace.
- For `codex_subagents`, launch actual separate spawned agents. If the runtime would only provide inline delegation, use manual fallback or stay local.
- For medium/complex work, produce a Parallel Decomposition Matrix before implementation. If independent streams exist and subagents are authorized, spawn all eligible streams in parallel.
- Local or sequential execution after the matrix requires a concrete dependency, write-conflict, shared-verification, external-resource, uncertainty, or repo-limit reason.
- Record model/reasoning choice and rationale for every spawned subagent. Do not set a model override casually; leave `model` unset to inherit unless policy permits the override.
- Never treat a subagent return or completion event as acceptance by itself.
- Do not close a stage before required verification succeeds or blockers are explicit.
- Create or select a Beads task before delegated, file-changing, >15 minute, or handoff-prone work.
- Fix in-scope debt now; any real defer must be explicit, bounded, tracked in Beads, and listed in handoff.
- Update Beads before close when task truth changed.

## When To Use

Use after lightweight triage classifies work as medium/complex, staged, delegated, review-heavy, docs-sensitive, risky, or repo-contract related.

Do not use full orchestration for trivial work that can finish safely in one local pass.

If the repo has no orchestration baseline or needs audit/reconcile, use `orchestration-setup` first.

## Start Algorithm

1. **Classify**
   - simple: small, local, low risk, no docs-sensitive dependency, no handoff/delegation value
   - medium/complex: multi-file, cross-boundary, docs-sensitive, risky, delegated, staged, or verification-heavy

2. **Simple local execution**
   - act as orchestrator and executor
   - do not consult catalog unless a concrete specialist gap appears
   - verify before claiming completion

3. **Medium/complex orchestration**
   - read repo contract layers
   - use `task-router` as the docs/skills/agents routing substep when routing matters
   - after routing, apply the required Superpowers workflow for the task type
   - create or select the relevant Beads task before delegation or file-changing execution
   - build the Parallel Decomposition Matrix before implementation
   - choose local execution, Codex subagents, or manual fallback based on the matrix, repo contract, runtime permission, isolation, parallelism, specialist value, and reviewability

4. **Centralize routing**
   - select relevant docs, skills, custom agents, and catalog candidates before launching subagents
   - pass selected assets into the subagent prompt
   - do not make children start with catalog discovery unless genuinely specialist or blocked
   - formulate the delegated task yourself: goal, success criteria, write zone, verification, stop rules, and selected assets

## Repo Contract

Read repo truth in this order:

1. `AGENTS.md`
2. `.codex/orchestrator.toml`
3. `.codex/handoff.md`
4. `.codex/project-index.md`
5. repo docs listed in the contract
6. current Beads state

Use repo-local entrypoints when present:

- process verification
- artifact validation
- completion inbox review
- stage ready check
- stage closeout
- workspace cleanup

Simple orchestration work stays local by default:

- Beads create/update/close and dependency maintenance
- handoff and stage-summary updates
- stage selection and decomposition
- prompt/task drafting
- routing summaries and analysis-only coordination

Delegation launcher policy:

- `delegation.launcher = "codex_subagents"`: launch built-in/custom Codex subagents directly when current runtime policy permits it, as separate visible agent threads/runs.
- `delegation.subagent_visibility = "separate_spawned_threads"` and `inline_subagents_allowed = false`: do not satisfy delegation with an inline internal agent summary.
- `delegation.requires_explicit_user_spawn_request = true`: only spawn when the current user request explicitly asks/allows subagents, for example "spawn/launch Codex subagents yourself when justified."
- `delegation.parallel_decomposition_matrix = "required_for_medium_complex"`: every medium/complex unit needs a brief stream matrix before implementation.
- `delegation.parallel_execution_default = "spawn_all_independent_streams"` and `sequential_requires_reason = true`: parallel is the default when streams are independent and subagents are authorized.
- `[subagent_model_policy]`: subagents inherit model/reasoning by default; reasoning is complexity-based; model override requires current user authorization or a clear task-specific reason; record the rationale.
- `delegation.launcher = "manual_user_launch"` or legacy `workspace.launch_mode = "manual_user_launch"`: produce manual prompt packs as fallback.
- `delegation.launcher = "none"`: keep all execution local unless the user explicitly overrides.

## Routing

Routing is orchestrator-owned and selective:

1. Authoritative/current docs first: Context7 for framework/library behavior, first-party docs for APIs/platforms/CLIs.
2. Installed skills or custom agents.
3. Local catalog only when no installed asset fits.
4. `skill_scout` only when ranking missing assets will materially help.

For delegated streams, include an explicit routing result:

- `Documentation`: exact source or `No dependency documentation lookup needed.`
- `Selected skills`: exact names/paths, or `none - <reason>`
- `Selected agents/personas`: exact names/paths, or `none - <reason>`
- `Catalog candidates`: promoted/lookup-only candidates, or `none - <reason>`

Prefer already-installed assets. Prefer practical CLI integrations over MCP when the repo policy says so.

Routing does not satisfy Superpowers requirements. After routing, continue with the process skill required by the work: brainstorming for new behavior, writing-plans for multi-step execution, systematic-debugging for failures, test-driven-development for code changes when appropriate, and verification-before-completion before completion claims.

## Delegation Policy

Delegate only when it improves speed, isolation, specialist quality, or reviewability.

Before delegating, check:

1. Can this finish locally in one pass?
2. Is there real isolation benefit?
3. Is there real parallelism benefit?
4. Is there real specialist benefit?
5. Can one stream own the full coherent outcome without losing reviewability?

If not, keep it local.

### Parallel Decomposition Matrix

Before implementation on any medium/complex stage, produce a brief matrix. Keep it compact, but make the decision auditable:

- `Stream`: short id/name.
- `Goal`: finished outcome.
- `Agent`: local, `explorer`, `docs_researcher`, `skill_scout`, `worker`, or custom agent.
- `Write zone`: owned files/modules, or read-only.
- `Dependencies`: upstream/downstream streams, shared resources, branch/worktree assumptions.
- `Verification`: targeted checks for that stream.
- `Model/reasoning`: inherited, role default, or explicit reasoning/model override with rationale.
- `Decision`: `parallel`, `sequential`, or `local`.
- `Reason`: why that decision is correct.

Classify a stream as parallel only when it has:

- disjoint write zone or read-only scope
- no dependency chain blocking start
- independent verification loop or a clearly mergeable targeted check
- no conflicting shared external mutation, lock, or repo stage limit
- separable specialist outcome

If two or more streams qualify and runtime policy permits separate spawned subagents, launch them in parallel. Keep each stream as the largest coherent unit inside its boundary.

If two or more streams qualify but current user permission is missing, ask for explicit spawned-subagent authorization instead of silently doing the work locally.

If parallelism does not qualify, use one cohesive stream and state the reason: dependency chain, write conflict, shared verification bottleneck, shared external resource, uncertain scope, or repo limit. Do not use a vague "files are coupled" reason without naming the coupled files/modules.

### Agent Choice

- `explorer`: read-heavy codebase mapping, impact analysis, or risk discovery.
- `docs_researcher`: version-sensitive framework/library/API/CLI/platform behavior.
- `skill_scout`: installed or staged skill/agent selection when local routing is unclear.
- `worker`: bounded implementation or fix with clear ownership.
- custom agents: only when their description fits better than a built-in role.

Do not spawn agents for symmetry or ceremony. Do not keep spawning to preserve momentum after limits or repeated failures.

### Model And Reasoning Policy

- Default: leave `model` unset and `reasoning_effort` unset so the subagent inherits the orchestrator/runtime default.
- Use low/medium reasoning for bounded exploration, catalog lookup, and low-risk isolated edits.
- Use high or xhigh reasoning for architecture, security, data migrations, cross-module changes, critical bugs, review, ambiguous requirements, or work that can create hard-to-find regressions.
- `docs_researcher`, `skill_scout`, and other fixed-profile roles use their role default when the runtime says their effort cannot be changed.
- Custom agents use their configured model/reasoning unless the task has a clear reason to override.
- Set an explicit `model` only when the current user explicitly authorizes model selection or the task has a clear task-specific reason. Prefer upgrading reasoning effort before changing model.
- Record `model`, `reasoning_effort`, and the rationale in the matrix, subagent prompt, artifact, and completion event when available.

### Subagent Prompt Contract

When launching a subagent, use the runtime mechanism that creates a separate visible Codex agent/thread/run. Use `.codex/subagent-spawn-template.md`, pass the relevant parts of `.codex/subagent-task-contract.md`, and include:

- Task ID / Beads reference for write-heavy, delegated, long-running, or handoff-prone streams
- role and agent type
- model/reasoning choice and rationale
- finished goal
- observable success criteria
- Documentation block
- Asset Routing block
- available context and selected files/docs
- write/read ownership boundaries
- exact verification commands
- artifact and completion-event requirements when defined
- stop/ask rules
- reminder that the subagent is not alone in the codebase and must not revert unrelated work

For workers, assign ownership explicitly. For parallel workers, write zones must be disjoint.
For write-heavy workers, assign a dedicated branch/worktree unless the repo contract explicitly allows shared-workspace execution.
Require the returned artifact to record `agent_type`, selected assets, write zone, and success criteria.

### Manual Fallback

Use manual prompt packs only when:

- the repo explicitly requires `manual_user_launch`
- built-in subagents are unavailable under current runtime policy
- the runtime only offers inline delegation instead of separate spawned agent threads
- the user asks for manual prompts

Manual prompts still use the same routing, boundary, verification, artifact, and completion-event contract. Add a short Russian `Краткая справка` after the prompt or prompt pack.
Manual fallback does not relax Beads, Superpowers, Asset Routing, Documentation, verification, or branch/worktree requirements.

## Execution Loop

1. **Inspect**
   - read repo contract layers
   - check branch/worktree state, local dirt, and Beads

2. **Pick the next unit**
   - choose the next realistic task or stage from current code, docs, blockers, and Beads
   - do not reopen closed scope without a verified defect or explicit user request
   - create/select the Beads task before execution when this unit changes files, delegates work, lasts >15 minutes, or may need handoff

3. **Decompose**
   - write the Parallel Decomposition Matrix for medium/complex work
   - choose all streams that can safely start now
   - keep simple orchestration tasks local

4. **Choose mode**
   - simple -> local
   - simple orchestration -> local
   - medium/complex with no delegation value -> local staged execution
   - one delegated boundary -> one cohesive subagent stream
   - independent delegated boundaries -> parallel subagent streams

5. **Execute and review**
   - work locally or launch subagents according to the chosen mode
   - while subagents run, do non-overlapping local work
   - review returned artifacts, completion events, diffs, and verification evidence
   - run relevant local verification before accepting

6. **Correct**
   - return in-scope corrections to the same stream when possible
   - open a new stream only if scope changed, old stream is unavailable, isolation must be replaced, or an independent second pass is warranted

7. **Accept or block**
   - accepted: artifact, diff, and verification satisfy the stream contract
   - not accepted: request correction or integrate manually with clear notes
   - blocked: record blocker and stop accepting that stream

8. **Mini-closeout**
   - update artifact frontmatter: `status`, `accepted_by_orchestrator`, `delivery_method`, `cleanup_status`, `cleanup_notes`
   - run safe-only cleanup for accepted streams when the repo provides it
   - never force-delete dirty worktrees or unproven local branches

9. **Stage close**
   - review complete
   - local verification complete
   - E2E/smoke applicability decided and run when repo-defined triggers apply
   - process verification and stage-ready checks run when present
   - `orchestration-closeout` used when leaving active work
   - Beads updated
   - handoff refreshed if current truth changed
   - stage summary written when the stage closed or materially shifted

## Risk Triggers

Treat these as higher risk:

- UI or user-visible workflow changes
- auth, security, secrets, payments, permissions, or privacy
- schema, migration, data-loss, or deployment changes
- public API, routing, or compatibility changes
- deploy/runtime integration or critical regression changes
- large diffs, multi-repo changes, protected-branch delivery
- repeated failed verification or unclear ownership

For higher-risk closeout, consider one targeted read-only review subagent. Do not fan out reviews by default.

Run repo-defined E2E/smoke checks when risk triggers require them. If no repo command exists, record `not available` or `not applicable`; do not invent a framework.

## Output Style

Keep communication concise and operational:

- current state
- next step
- agent launches or findings
- verification result

Prefer explicit decisions and boundaries over long prompt dumps.
